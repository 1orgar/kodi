__version__ = "1.0"
from debug import CDebug
