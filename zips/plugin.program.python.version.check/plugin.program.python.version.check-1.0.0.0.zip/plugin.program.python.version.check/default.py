# -*- coding: utf-8 -*-

import sys
import xbmcaddon
import xbmcgui

__settings__ = xbmcaddon.Addon(id='plugin.program.python.version.check')
__plugin__ = __settings__.getAddonInfo('name')
__root__ = __settings__.getAddonInfo('path')

if __name__ == "__main__":
    xbmcgui.Dialog().ok('Pyhhon version check', 'You\'re using python version:', str(sys.version))
